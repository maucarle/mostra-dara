# Il Nodo di Dara — Design System

A small, focused design system for **Il Nodo di Dara**, a photographic exhibition by **Elisabetta Acquaviva** on view at **Museo della Città di Rimini**, 7 marzo – 10 maggio 2026. The project documents the experience of menopause through portraits and testimonies of 100 women.

The system is small on purpose. The brand is essentially: **ivory type on near-black, one gold accent, Poppins for everything loud and quiet (with Alright Sans on hand for kickers), a faint grain over everything.** No icons that aren't necessary, no second hue, no rounded corners.

> **Note on language.** All product copy is in Italian. The design system documentation is in English to keep things skim-readable for non-Italian designers, but every example string is preserved in the original Italian.

---

## Sources used to build this system

- **GitHub:** [`maucarle/mostra-dara`](https://github.com/maucarle/mostra-dara) — the live exhibition site (`www.ilnododidara.com`). Hand-rolled HTML5 / CSS3 / vanilla JS, deployed on Cloudflare Pages. We read the whole tree: landing, `/progetto`, `/eventi`, `/foresta-sospesa`, `/soundscape`, `/rassegna-stampa`, `/stampa`. If you can clone this repo locally you will get the authoritative tokens, all 15 `locandinaN.jpg` carousel images, the press-kit PDF, and the testimonies for *La Foresta Sospesa*.
- **Production site:** [ilnododidara.com](https://www.ilnododidara.com)
- **Artist site:** [elisabettacquaviva.it](https://elisabettacquaviva.it)

If you are building anything new for Elisabetta or the exhibition, **start with the GitHub repo** — the CSS in `index.html` and `progetto/index.html` is the source of truth for tokens; this design system is a distillation.

---

## File index

```
README.md                                  ← you are here
SKILL.md                                   ← Claude Skills compatible entry-point
colors_and_type.css                        ← the full token set + semantic element styles
FOresta Sospesa — Esperienza.html          ← the immersive after-show experience (4 atti)
foresta-experience/                        ← components, audio engine, data
  app.jsx                                  ← React state machine + scene components
  styles.css                               ← experience-specific stylesheet
  data.js                                  ← testimony fragments + 3D layout
  audio.js                                 ← procedural ambient drone (Web Audio API)
fonts/                                     ← (empty by default — see Fonts section.
                                              Drop AlrightSans-*.woff2 in
                                              fonts/alright-sans/ if licensed.)
assets/
  logo.jpeg                                ← the Nodo-tree mark (raster JPEG from production)
  imagery/                                 ← 6 representative locandina photographs (B&W portraits)
  patterns/grain.svg                       ← the fractal-noise grain overlay, isolated
preview/                                   ← 18 design-system review cards
```

---

## Project context

**Il Nodo di Dara** ("The Knot of Dara") takes its name from a Celtic knot symbolizing the deep roots of the oak. The exhibition presents 100 portraits of women between 45 and 65, each paired with a recorded testimony, in a single room arranged as a *foresta sospesa* — a "suspended forest" of photographs hung from threads.

The thesis, in Elisabetta's own words: *"Il corpo femminile non è oggetto di giudizio, ma territorio di mutamento."* (The female body is not an object of judgement, but a territory of change.) The exhibition is positioned not as journalism about menopause but as **collective, dignified portraiture** — photography as care.

### Surfaces in scope

The public-facing product is a single responsive website with seven pages:

| Slug | Page | Role |
|---|---|---|
| `/` | Landing — phase 1 teaser → phase 2 reveal | Countdown to vernissage, primary CTA. |
| `/progetto` | "Il Progetto" | The artistic statement, biography, list of rooms, ringraziamenti. |
| `/eventi` | "Eventi" | A calendar of talks/workshops with inline Luma booking. |
| `/foresta-sospesa` | "La Foresta Sospesa" | The 100 portraits + testimonies, presented as hanging cards with click/hover/timer reveal modes. |
| `/soundscape` | "Soundscape" | A single fullscreen play button for the exhibition's ambient soundtrack. |
| `/rassegna-stampa` | "Stampa" | Press coverage grid. |
| `/stampa` | Press kit (noindex) | Downloadable assets for journalists. |

We've built **one UI kit** (`ui_kits/site/`) covering all of the above; the brand never needs a second product. There is no app, no docs site, no admin.

---

## Content fundamentals

The voice is **Italian, intimate, reverent, and refuses euphemism.** The defining stylistic move is putting the word *menopausa* in the mouth of the speaker — out loud, repeatedly, without softening — and then surrounding it with the language of growth: *radici, intreccio, nodo, soglia, accoglienza, rinascita*.

- **Person.** Mostly first person ("Ciao, sono Elisabetta, ho 53 anni e sono in menopausa.") with occasional direct address to the reader (*"Prenditi del tempo"*). Never corporate "we".
- **Register.** Conversational but literary. Long sentences with em-dashes are common in testimony copy; UI copy is short and uppercase.
- **Casing.** Two register only:
  - **UPPERCASE** with wide tracking for nav, page titles, section labels, badges, buttons.
  - **Sentence case** for prose, taglines, blockquotes, names. Title case is never used in the wild.
- **Punctuation.** Italian quotation style ("…") and the middle dot `·` as a sub-divider everywhere ("Rimini · Museo della Città · 2026"). Em-dashes `—` and en-dashes `–` are used; double-quotes `"…"` are common too, used for spoken phrases. The numeric date format is "7 marzo 2026" with month names spelled out; in titles, "7 mar — 10 mag" with hyphenated short forms.
- **Numerals & symbols.** Numbers are written as digits in event listings ("14 Sab", "16:00 – 18:30") and spelled out in prose ("100 donne", "53 anni").
- **Emoji.** None. There is not a single emoji in the production site, and the brand should not introduce them.
- **Iconography in copy.** Almost none. The only recurring marks are: the **middle dot `·`** as separator, the **em-dash `—`** as a setting-off device, and the **ampersand-arrow `&rarr;` / `→`** on the primary CTA ("Entra nella mostra →").

### Specific phrases that define the voice

- *"Non è un ciclo che si chiude, è una radice che si fortifica."* — the project tagline.
- *"Io non fotografo, io accompagno."* — the artist's self-description; appears as a pull quote.
- *"Qualcosa affiora tra"* — the countdown label (note: not "Inaugurazione tra" — the brand prefers the lyrical "something surfaces in"). 
- *"Entra nella mostra →"* — the only primary CTA on the site.
- *"Un progetto di Elisabetta Acquaviva"* — the footer signature; the brand never says "© 2026 Nodo di Dara".

When you write new copy, ask: *would Elisabetta say this out loud at the vernissage?* If it sounds like a marketing email, rewrite.

---

## Visual foundations

### Color
Three families, no more. **Oro** (gold `#c9a96e`) is the only chromatic accent; it appears at full strength on titles, the CTA button, and one icon stroke per page. Body text is **ivory `#f5f5f0`** at 50–75% opacity over a near-black `#0e0c0a` background. There is **no secondary hue.** The only place that breaks this rule is the `/soundscape` page, which uses a `160°` linear gradient `#1e1a17 → #7a6855` to evoke the warmth of an enclosed listening room. See `preview/colors-*.html`.

### Type
A **two-family system** with clear role separation (recovered from the panels PDF, May 2026):

- **Poppins** — the workhorse. Carries **display titles** (weight 700/800, uppercase, tracking `0.02–0.04em`), **body prose** (weight 300, tracking 0), and **the italic voice** for taglines, testimony fragments and pull quotes (weight 400/500 italic). Geometric, slightly humanist, reads boldly in caps without looking generic. All weights are open-source via Google Fonts.
- **Alright Sans** — the *quiet partner*. A commercial humanist sans used at small sizes for **kickers, sub-titles, captions** — "RITRATTI DI DONNE IN MENOPAUSA", "EVENTI", "MARZO 2026", etc. Weight 300 (Light) and 500 (Medium), tracking `0.20–0.28em`, always uppercase. Falls back to Poppins Light/Medium cleanly when the license isn't loaded.

The website `ilnododidara.com` uses a different stack (Barlow Condensed / Cormorant Garamond / Barlow); see "Fonts" below for the web-only archive variables.

### Spacing & layout
Centered single-column at `max-width: 900px` with page gutters of `44px` desktop / `24px` mobile. Vertical rhythm is generous: section padding `100px` top + bottom, never compressed. There is no card grid for prose — every long-form page is a single column. Grids only appear for **press cards** (2-column) and **event listings** (date / body / actions tri-column).

### Backgrounds
- Always near-black `#0e0c0a` (except `/soundscape`).
- Always overlaid with a **fractal-noise grain SVG** at `0.5` opacity. The grain is non-negotiable — it's the brand's tactile signature. The grain texture is in `assets/patterns/grain.svg`.
- A **radial protection gradient** sits over the landing's center to deepen the vignette (`radial-gradient(ellipse at 50% 40%, transparent 30%, rgba(0,0,0,0.55) 100%)`).
- **No** patterns, hand-drawn illustrations, or repeating textures. The imagery itself — Elisabetta's portraits — supplies all the texture the page needs. Imagery is **always black-and-white**, often slightly sepia-tinted (`filter: sepia(15%) brightness(0.88)`) and shot at low key.

### Animation
A handful of named curves, all gentle:
- **"arise"** — the page entrance. `cubic-bezier(0.16, 1, 0.3, 1)`, 2s, opacity 0→1 + 20px translate-up. Every hero block uses this; nothing else does.
- **"breathe"** — the logo on the teaser pulses opacity 0.7 → 0.88 and scale 1 → 1.02 over 7s.
- **"sway"** — hanging cards in the *foresta sospesa* rotate ±0.8° on a 5.5–7s loop, randomised per card.
- **Fade transitions** — `0.3s` for hovers, `0.55s` for didascalia reveals, `1s` cross-fade between carousel photographs.
- **No bounces, no springs, no parallax, no scroll-jacking.** The site behaves like a printed catalogue: it sits still and waits.

### Hover, focus, press states
- **Hover (text links):** color slides `var(--white-low) → var(--oro)` over `0.3s`. That's it.
- **Hover (cards):** `border-color: var(--oro-dim) → var(--oro-mid)` and `background: transparent → rgba(201,169,110,0.05)`. No translate, no scale.
- **Hover (primary CTA):** `opacity: 1 → 0.85`. No color shift.
- **Press:** no explicit pressed state in the production code. We do not shrink or darken; we treat the click as instantaneous.
- **Focus:** the site does not currently style `:focus` rings. New work should add a `2px outline: var(--oro-mid)` for accessibility (this is the one place we recommend departing from the production code).

### Borders, dividers, shadows, transparency
- Borders are **always 1px** and almost always `var(--oro-dim)` (gold at 18% opacity). Section breaks are a single hairline; never two.
- **Shadows** appear only on suspended objects (cards in the foresta hang against the wall: `0 8px 40px rgba(0,0,0,0.5)`) and modals (`0 30px 80px rgba(0,0,0,0.7)`). UI buttons / cards / inputs cast no shadow.
- **Inner shadows / insets:** none.
- **Capsules vs. protection gradients:** the brand strongly prefers **protection gradients** (a vertical fade from `transparent → rgba(20,15,10,0.97)`) over solid capsules to anchor caption text on photographs. Capsules don't appear anywhere.
- **Transparency** is the system's primary expressive tool. The same `#c9a96e` appears at 100% (titles, CTA), 55% (kickers), 18% (borders), 8% (card wash), 2% (default card surface). Likewise ivory at 100/75/50%.
- **Backdrop blur** is reserved for the fixed `nav` (4px) and the foresta modal background (6px). Don't add it elsewhere.

### Corner radii
**Sharp.** `border-radius: 0` is the default for every box, card, button, image, badge, and modal in the system. The two exceptions are: (1) **circular icon buttons** (`border-radius: 50%`) — only the soundscape play button uses this — and (2) **circular badge dots** if you ever need them. If you find yourself reaching for `8px` rounded cards, you're building a different brand.

### Cards
A "card" in this system is almost always: 1px hairline border, 28px padding, no shadow, no rounded corners, optional faint gold wash on hover. The hanging cards in the *foresta* are a separate species — full-bleed B&W photo, full-height linear-gradient overlay for caption, slight sepia filter on the photo itself.

### Layout rules / fixed elements
- The **nav** is `position: fixed` and has a gradient mask (`linear-gradient(to bottom, rgba(14,12,10,0.96), transparent)`) so content can scroll underneath. It is always 18–20px tall and always uses `backdrop-filter: blur(4px)`.
- The **footer** is *not* fixed; it sits at the natural end of content and is separated by a 1px hairline.
- A "page header" is exactly: kicker → title → 60px hairline (60×1px gold-dim) → italic tagline. This pattern is repeated on every section header inside `/progetto`.

### Photographic vibe
Black-and-white, low-key, contemplative. Almost every portrait places the subject in shadow with a single warm key light catching the side of the face or a hand. Subjects are typically **closing their eyes, looking away, or partially obscured** by an object (fan, hand, fabric, hair). The result is intimate without being voyeuristic. **No color photography. No on-location/lifestyle imagery.** If you need a placeholder, use a B&W still life — never a stock photo.

---

## Iconography

There is almost no iconography in this brand. It is a typographic system that uses real photographs as its only visual furniture.

Where icons do appear in the production code, they are **inline SVG, 12–20px, single-color, 1.5px stroke or solid fill of `var(--oro-mid)` or `currentColor`**. They are never branded, never illustrative, and never paired with text labels longer than two words. The complete inventory from the codebase:

| Icon | Where | Style |
|---|---|---|
| **Map pin** (filled) | Event location row | 12×12 px filled `var(--oro-mid)` |
| **Chevron right** | "Scopri →" button on event cards | 14×14 stroked `currentColor`, `stroke-width: 1.5` |
| **External-link arrow** (line+arrow into corner) | Press cards | 12×12 stroked `currentColor`, `stroke-width: 1.5` |
| **Play triangle / Pause bars** (filled) | Soundscape page | 35×35 inside an 90px circle button, filled `currentColor` |
| **Hamburger** | Mobile nav | Three 24×1px stacked rules, 5px gap |
| **Video play circle** | Inactive video placeholders on `/progetto` | 52×52 circle with 20×20 triangle, 1px border |

These are all hand-written inline SVGs, not from a library. The system **does not currently use** Lucide, Heroicons, FontAwesome, or any icon font, and adding one is discouraged — pick the closest-matching glyph from the inventory above and inline it. If you genuinely need an icon that doesn't exist, **Lucide** is the closest match stylistically (1.5px stroke, geometric, calm) and would be the recommended substitution — but flag it.

**Emoji:** never. **Unicode characters used as icons:** the middle dot `·` (U+00B7), em-dash `—` (U+2014), right arrow `→` (U+2192), `&rarr;` in the CTA. That's the full set.

### Logo
The mark is a hand-drawn Celtic knot rendered as a tree: trunk-knot above, root-knot below, all enclosed in an open circle. It is delivered as a single raster JPEG (`assets/logo.jpeg`, ~232KB, square, with the title "NODO DI DARA / RITRATTI DI DONNE IN MENOPAUSA" baked in below the symbol). The site always invokes it with `filter: invert(1)` to render it ivory-on-black. There is **no SVG or vector version** — flag this if a print or large-display use case appears; a redrawn vector is on the open to-do list.

---

## Fonts — recovered from the official exhibition panels

**Source of truth:** `NODO_DI_DARA_ESEC_pannelli_mostra_3_3_26.pdf` (the InDesign-exported panels that hang on the walls of the show). Inspecting the embedded font subsets in that PDF reveals the **canonical brand stack**:

| Role | Family | Weights used | License |
|---|---|---|---|
| **Display / titles** | **Poppins** | 700 (Bold), 800 (ExtraBold) | Open — Google Fonts |
| **Body / prose** | **Poppins** | 300 (Light), 400 (Regular), 500 (Medium) | Open — Google Fonts |
| **Voice / italic** | **Poppins** | 400 italic, 500 italic | Open — Google Fonts |
| **Kicker / labels** | **Alright Sans** | 300 (Light), 500 (Medium) | **Commercial** — [MVB Fonts](https://mvbfonts.com/fonts/alright-sans/) |

- **Poppins** loads via Google Fonts `@import` at the top of `colors_and_type.css`. No license action needed.
- **Alright Sans** is commercial and cannot be redistributed in this repo. `colors_and_type.css` declares an `@font-face` that points at `fonts/alright-sans/AlrightSans-Light.woff2` / `AlrightSans-Medium.woff2`; drop the licensed files in that folder and the type system upgrades automatically. Until that happens, **Alright Sans falls back cleanly to Poppins** for every role, so nothing visibly breaks.

---

## Caveats & open items

These are the things the production site itself acknowledges or that we noticed while building this kit — they're worth knowing before you make new work:

- **The logo is raster only.** A redrawn vector would be welcome for any large-format / print application.
- **No focus styles** are defined in production CSS. We've recommended adding `2px outline: var(--oro-mid)` but the current site is not accessibility-audited.
- **6 of 11** Foresta Sospesa portraits don't have final photographs yet (Eleonora, Lorella, Chiara, Lucia, Monica, Eugenia, Elena). The `foresta-sospesa/index.html` includes a placeholder treatment — a dark `var(--bark)` panel with the card number + name in Cormorant. Reuse it.
- **The inaugurazione gallery** (`/inaugurazione`) is a placeholder; new photos + a YouTube embed are pending.
- **No design tokens are exposed as JSON or as a `tokens.json`.** Everything lives in CSS custom properties. If you need to consume from another tool, regenerate from `colors_and_type.css`.

---

## Index of UI kit + preview cards

- `ui_kits/site/index.html` — a click-through recreation of the full public site (landing, projecto, eventi, foresta, soundscape, stampa) as a single mounted React app.
- `preview/*.html` — 18 review cards rendered into the Design System tab: brand mark, palette splits, type specimens, spacing, motion notes, nav, hero, event card, suspended card, press card, modal, CTA + button states, soundscape player, badge, iconography inventory, photograph treatment.
