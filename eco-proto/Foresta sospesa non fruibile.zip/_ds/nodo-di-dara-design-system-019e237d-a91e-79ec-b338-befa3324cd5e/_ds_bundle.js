/* @ds-bundle: {"format":3,"namespace":"NodoDiDaraDesignSystem_019e23","components":[],"sourceHashes":{"foresta-experience/app.jsx":"4923f90a579b","foresta-experience/audio.js":"a5a93959cf09","foresta-experience/data.js":"fe51511b60c0"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.NodoDiDaraDesignSystem_019e23 = window.NodoDiDaraDesignSystem_019e23 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// foresta-experience/app.jsx
try { (() => {
/* global React, ReactDOM, FORESTA_DATA, ForestaAudio */
/* ════════════════════════════════════════════════════════════════════════
   FORESTA SOSPESA — ESPERIENZA
   Una traversata in quattro atti:
     I.  Soglia    — i numeri della mostra, l'invito a entrare
     II. Foresta   — le tende sospese in uno spazio 3D, in lieve sway
     III. Voce     — una testimonianza letta come partitura tipografica
     IV. Coro      — sussurri collettivi che salgono dalle tende

   Tutto in un solo file Babel per non perdere scope tra componenti.
   ════════════════════════════════════════════════════════════════════════ */

const {
  useState,
  useEffect,
  useRef,
  useMemo,
  useCallback
} = React;

/* ─────────────────────────────────────────────────────────────────────────
   GLOBAL CHROME — grain overlay + ambient audio toggle + tweaks
   ───────────────────────────────────────────────────────────────────────── */

function GrainOverlay() {
  return /*#__PURE__*/React.createElement("div", {
    className: "grain",
    "aria-hidden": "true"
  });
}
function AudioToggle({
  on,
  onToggle
}) {
  return /*#__PURE__*/React.createElement("button", {
    className: "audio-toggle " + (on ? "on" : "off"),
    onClick: onToggle,
    "aria-label": on ? "Disattiva audio ambientale" : "Attiva audio ambientale"
  }, /*#__PURE__*/React.createElement("span", {
    className: "audio-toggle__bars",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null)), /*#__PURE__*/React.createElement("span", {
    className: "audio-toggle__label"
  }, on ? "audio · on" : "audio · off"));
}

/* ─────────────────────────────────────────────────────────────────────────
   ATTO I · SOGLIA — la mostra è chiusa, la foresta no
   ───────────────────────────────────────────────────────────────────────── */

function Soglia({
  onEnter
}) {
  const stats = FORESTA_DATA.stats;
  return /*#__PURE__*/React.createElement("section", {
    className: "scene soglia",
    "data-screen-label": "I \xB7 Soglia"
  }, /*#__PURE__*/React.createElement("div", {
    className: "soglia__inner"
  }, /*#__PURE__*/React.createElement("p", {
    className: "kicker arise",
    style: {
      animationDelay: "0.2s"
    }
  }, "7 marzo \u2014 10 maggio 2026 \xB7 Museo della Citt\xE0 \xB7 Rimini"), /*#__PURE__*/React.createElement("h1", {
    className: "soglia__title arise",
    style: {
      animationDelay: "0.6s"
    }
  }, "La mostra \xE8 chiusa.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("em", null, "La foresta no.")), /*#__PURE__*/React.createElement("p", {
    className: "soglia__lede arise",
    style: {
      animationDelay: "1.4s"
    }
  }, "In sessantaquattro giorni pi\xF9 di ottomila persone hanno attraversato la sala, toccato le tende, ascoltato le voci, lasciato una parola sul registro.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("br", null), "Questa \xE8 l'eco di quel passaggio."), /*#__PURE__*/React.createElement("ul", {
    className: "stats arise",
    style: {
      animationDelay: "2.0s"
    }
  }, stats.map((s, i) => /*#__PURE__*/React.createElement("li", {
    className: "stat",
    key: i,
    style: {
      animationDelay: `${2.2 + i * 0.15}s`
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "stat__value"
  }, s.value), /*#__PURE__*/React.createElement("span", {
    className: "stat__unit"
  }, s.unit), /*#__PURE__*/React.createElement("span", {
    className: "stat__caption"
  }, s.caption)))), /*#__PURE__*/React.createElement("blockquote", {
    className: "soglia__quote arise",
    style: {
      animationDelay: "2.8s"
    }
  }, "\xABNon era una mostra. Era un coro.\xBB", /*#__PURE__*/React.createElement("cite", null, "dal registro dei visitatori")), /*#__PURE__*/React.createElement("button", {
    className: "cta arise",
    style: {
      animationDelay: "3.4s"
    },
    onClick: onEnter
  }, /*#__PURE__*/React.createElement("span", null, "Attraversa la foresta"), /*#__PURE__*/React.createElement("span", {
    className: "cta__arrow"
  }, "\u2192")), /*#__PURE__*/React.createElement("p", {
    className: "soglia__hint arise",
    style: {
      animationDelay: "4.2s"
    }
  }, "\u2193 scorri per entrare \xB7 5 minuti di traversata")));
}

/* ─────────────────────────────────────────────────────────────────────────
   ATTO II · FORESTA — 3D scene, tende sospese, sway, parallax cursore
   ───────────────────────────────────────────────────────────────────────── */

function Curtain({
  voice,
  layout,
  onOpen,
  focused,
  dim
}) {
  const styleVars = {
    "--x": layout.x + "vw",
    "--y": layout.y + "vh",
    "--z": layout.z + "px",
    "--w": layout.w + "px",
    "--sway-d": layout.sway.d + "s",
    "--sway-lag": layout.sway.lag + "s",
    "--sway-amp": layout.sway.amp + "deg"
  };
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "curtain " + (focused ? "is-focused " : "") + (dim ? "is-dim" : ""),
    style: styleVars,
    onClick: () => onOpen(voice.id),
    "aria-label": `Apri la voce di ${voice.name}, ${voice.age} anni`
  }, /*#__PURE__*/React.createElement("span", {
    className: "curtain__thread",
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("span", {
    className: "curtain__inner"
  }, /*#__PURE__*/React.createElement("img", {
    className: "curtain__photo",
    src: voice.photo,
    alt: "",
    loading: "lazy",
    draggable: "false"
  }), /*#__PURE__*/React.createElement("span", {
    className: "curtain__veil",
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("span", {
    className: "curtain__meta"
  }, /*#__PURE__*/React.createElement("span", {
    className: "curtain__name"
  }, voice.name), /*#__PURE__*/React.createElement("span", {
    className: "curtain__age"
  }, voice.age)), /*#__PURE__*/React.createElement("span", {
    className: "curtain__incipit"
  }, voice.incipit)));
}
function Foresta({
  onOpenVoice,
  onCoro
}) {
  const [parX, setParX] = useState(0);
  const [parY, setParY] = useState(0);
  const [hoveredId, setHoveredId] = useState(null);
  const stageRef = useRef(null);

  // mouse-look parallax. Mouse position drives slight horizontal tilt + vertical pan.
  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    let raf = 0;
    let targetX = 0,
      targetY = 0,
      curX = 0,
      curY = 0;
    const onMove = e => {
      const rect = stage.getBoundingClientRect();
      targetX = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
      targetY = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
    };
    const tick = () => {
      curX += (targetX - curX) * 0.06;
      curY += (targetY - curY) * 0.06;
      setParX(curX);
      setParY(curY);
      raf = requestAnimationFrame(tick);
    };
    stage.addEventListener("mousemove", onMove);
    raf = requestAnimationFrame(tick);
    return () => {
      stage.removeEventListener("mousemove", onMove);
      cancelAnimationFrame(raf);
    };
  }, []);

  // hover detection via event delegation on the stage — keeps focus state lightweight
  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    const onOver = e => {
      const c = e.target.closest(".curtain");
      if (c) setHoveredId(c.dataset.id || null);
    };
    const onOut = e => {
      if (!e.relatedTarget || !e.relatedTarget.closest || !e.relatedTarget.closest(".curtain")) {
        setHoveredId(null);
      }
    };
    stage.addEventListener("mouseover", onOver);
    stage.addEventListener("mouseout", onOut);
    return () => {
      stage.removeEventListener("mouseover", onOver);
      stage.removeEventListener("mouseout", onOut);
    };
  }, []);

  // map voices ↔ layout entries (data.layout has the same id keys)
  const items = useMemo(() => {
    const byId = Object.fromEntries(FORESTA_DATA.voices.map(v => [v.id, v]));
    return FORESTA_DATA.layout.map(l => ({
      voice: byId[l.id],
      layout: l
    }));
  }, []);

  // camera transform — slight rotation Y from parX, slight translateY from parY, gentle constant drift forward
  const camTransform = `rotateY(${parX * -6}deg) rotateX(${parY * 3}deg) translateX(${parX * -40}px)`;
  return /*#__PURE__*/React.createElement("section", {
    className: "scene foresta",
    "data-screen-label": "II \xB7 Foresta",
    ref: stageRef
  }, /*#__PURE__*/React.createElement("div", {
    className: "foresta__title arise"
  }, /*#__PURE__*/React.createElement("p", {
    className: "kicker"
  }, "Atto II \xB7 La foresta sospesa"), /*#__PURE__*/React.createElement("p", {
    className: "foresta__legend"
  }, /*#__PURE__*/React.createElement("em", null, "Muovi il cursore per guardarti intorno. Tocca una tenda per entrare nella voce."))), /*#__PURE__*/React.createElement("div", {
    className: "world"
  }, /*#__PURE__*/React.createElement("div", {
    className: "world__cam",
    style: {
      transform: camTransform
    }
  }, items.map(({
    voice,
    layout
  }) => /*#__PURE__*/React.createElement("div", {
    key: voice.id,
    "data-id": voice.id,
    style: {
      display: "contents"
    }
  }, /*#__PURE__*/React.createElement(Curtain, {
    voice: voice,
    layout: layout,
    onOpen: onOpenVoice,
    focused: hoveredId === voice.id,
    dim: hoveredId && hoveredId !== voice.id
  }))))), /*#__PURE__*/React.createElement("button", {
    className: "coro-trigger",
    onClick: onCoro
  }, /*#__PURE__*/React.createElement("span", null, "Ascolta il coro \u2192")));
}

/* ─────────────────────────────────────────────────────────────────────────
   ATTO III · VOCE — la testimonianza letta come partitura tipografica
   ───────────────────────────────────────────────────────────────────────── */

function Waveform({
  playing,
  density = 90
}) {
  // 90 vertical bars whose heights are seeded by sin/noise; animation is purely CSS.
  const bars = useMemo(() => {
    const out = [];
    for (let i = 0; i < density; i++) {
      const phase = i / density;
      // a "voice" curve: louder mid, softer edges, with pseudo-random texture
      const env = Math.sin(phase * Math.PI);
      const noise = Math.sin(i * 12.9898) * 43758.5453;
      const wobble = noise - Math.floor(noise);
      const h = Math.max(0.08, env * (0.4 + wobble * 0.6));
      out.push({
        h,
        delay: i * 23 % 1200
      });
    }
    return out;
  }, [density]);
  return /*#__PURE__*/React.createElement("div", {
    className: "waveform " + (playing ? "is-playing" : ""),
    "aria-hidden": "true"
  }, bars.map((b, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    className: "waveform__bar",
    style: {
      "--h": b.h * 100 + "%",
      "--delay": b.delay + "ms"
    }
  })));
}
function VoiceFlow({
  stanzas,
  playing,
  onComplete
}) {
  // Reveal stanza by stanza. Each stanza waits a beat appropriate to its kind
  // before the next reveals. Cue beats are longer (silences).
  const [revealed, setRevealed] = useState(0);
  useEffect(() => {
    if (!playing) return;
    if (revealed >= stanzas.length) {
      onComplete && onComplete();
      return;
    }
    const cur = stanzas[revealed];
    const dwell = cur.kind === "cue" ? 2200 : cur.kind === "beat" ? 2600 : 2400;
    const t = setTimeout(() => setRevealed(r => r + 1), dwell);
    return () => clearTimeout(t);
  }, [playing, revealed, stanzas, onComplete]);

  // restart when playing toggles from false → true after completion
  useEffect(() => {
    if (playing && revealed >= stanzas.length) setRevealed(0);
  }, [playing]); // eslint-disable-line

  return /*#__PURE__*/React.createElement("div", {
    className: "voice-flow"
  }, stanzas.map((s, i) => /*#__PURE__*/React.createElement("p", {
    key: i,
    className: "voice-flow__line voice-flow__line--" + s.kind + (i < revealed ? " is-shown" : "")
  }, s.kind === "cue" ? /*#__PURE__*/React.createElement("span", {
    className: "voice-flow__bracket"
  }, "[", s.text, "]") : s.text)));
}
function Voce({
  voiceId,
  onBack,
  onNext,
  onPrev
}) {
  const voice = FORESTA_DATA.voices.find(v => v.id === voiceId);
  const [playing, setPlaying] = useState(false);

  // Auto-start the partitura after a brief settle.
  useEffect(() => {
    setPlaying(false);
    const t = setTimeout(() => setPlaying(true), 1100);
    return () => clearTimeout(t);
  }, [voiceId]);
  if (!voice) return null;
  return /*#__PURE__*/React.createElement("section", {
    className: "scene voce",
    "data-screen-label": "III \xB7 Voce",
    key: voiceId
  }, /*#__PURE__*/React.createElement("button", {
    className: "voce__back",
    onClick: onBack,
    "aria-label": "Torna alla foresta"
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, "\u2190"), " torna alla foresta"), /*#__PURE__*/React.createElement("div", {
    className: "voce__grid arise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "voce__photo-wrap"
  }, /*#__PURE__*/React.createElement("img", {
    src: voice.photo,
    alt: `Ritratto di ${voice.name}`,
    className: "voce__photo"
  }), /*#__PURE__*/React.createElement("div", {
    className: "voce__photo-veil",
    "aria-hidden": "true"
  })), /*#__PURE__*/React.createElement("div", {
    className: "voce__body"
  }, /*#__PURE__*/React.createElement("p", {
    className: "kicker"
  }, "una voce dalla foresta"), /*#__PURE__*/React.createElement("h2", {
    className: "voce__name"
  }, voice.name, /*#__PURE__*/React.createElement("span", {
    className: "voce__age"
  }, ", ", voice.age, " anni")), /*#__PURE__*/React.createElement("p", {
    className: "voce__incipit"
  }, /*#__PURE__*/React.createElement("em", null, voice.incipit)), /*#__PURE__*/React.createElement("div", {
    className: "voce__player"
  }, /*#__PURE__*/React.createElement("button", {
    className: "play-btn",
    onClick: () => setPlaying(p => !p),
    "aria-label": playing ? "Metti in pausa" : "Riprendi"
  }, playing ? /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    width: "20",
    height: "20"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "6",
    y: "5",
    width: "4",
    height: "14",
    fill: "currentColor"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "14",
    y: "5",
    width: "4",
    height: "14",
    fill: "currentColor"
  })) : /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    width: "20",
    height: "20"
  }, /*#__PURE__*/React.createElement("polygon", {
    points: "6,4 20,12 6,20",
    fill: "currentColor"
  }))), /*#__PURE__*/React.createElement(Waveform, {
    playing: playing
  }), /*#__PURE__*/React.createElement("span", {
    className: "voce__duration"
  }, voice.duration)), /*#__PURE__*/React.createElement("p", {
    className: "voce__audio-note"
  }, /*#__PURE__*/React.createElement("em", null, "traccia audio reale da incollare \u2014 qui la partitura tipografica.")), /*#__PURE__*/React.createElement(VoiceFlow, {
    stanzas: voice.stanzas,
    playing: playing
  }), /*#__PURE__*/React.createElement("div", {
    className: "voce__nav"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onPrev
  }, "\u2190 voce precedente"), /*#__PURE__*/React.createElement("button", {
    onClick: onNext
  }, "voce successiva \u2192")))));
}

/* ─────────────────────────────────────────────────────────────────────────
   ATTO IV · CORO — chiusura collettiva, sussurri che salgono
   ───────────────────────────────────────────────────────────────────────── */

function Coro({
  onRestart,
  onForest
}) {
  const whispers = FORESTA_DATA.chorus;
  // pre-compute positions for each whisper so they don't shift on rerender
  const positions = useMemo(() => whispers.map((w, i) => ({
    x: i * 73 % 90 - 45 + Math.sin(i) * 5,
    // -45..45 vw
    y: -10 + i / whispers.length * 110,
    // bottom-up
    d: 8 + i % 5 * 1.4,
    // duration
    lag: i * 0.7 % 4,
    size: 0.85 + i * 13 % 7 / 10 // 0.85..1.55
  })), [whispers]);
  const photos = FORESTA_DATA.voices;
  return /*#__PURE__*/React.createElement("section", {
    className: "scene coro",
    "data-screen-label": "IV \xB7 Coro"
  }, /*#__PURE__*/React.createElement("div", {
    className: "coro__photos"
  }, photos.map((v, i) => /*#__PURE__*/React.createElement("img", {
    key: v.id,
    src: v.photo,
    alt: "",
    className: "coro__photo",
    style: {
      "--x": i * 31 % 80 - 40 + "vw",
      "--lag": i * 0.5 + "s",
      "--scale": 0.7 + i % 3 * 0.15
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "coro__veil",
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", {
    className: "coro__whispers",
    "aria-hidden": "true"
  }, whispers.map((w, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    className: "coro__whisper",
    style: {
      "--x": positions[i].x + "vw",
      "--d": positions[i].d + "s",
      "--lag": positions[i].lag + "s",
      "--size": positions[i].size
    }
  }, w))), /*#__PURE__*/React.createElement("div", {
    className: "coro__center arise"
  }, /*#__PURE__*/React.createElement("p", {
    className: "kicker"
  }, "Atto IV \xB7 Il coro"), /*#__PURE__*/React.createElement("h2", {
    className: "coro__title"
  }, "Cento voci.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("em", null, "Una foresta che continua a respirare.")), /*#__PURE__*/React.createElement("p", {
    className: "coro__caption"
  }, "Le frasi che salgono dalle tende vengono dal registro", /*#__PURE__*/React.createElement("br", null), "dei visitatori della mostra. Cento ritratti, mille voci."), /*#__PURE__*/React.createElement("div", {
    className: "coro__actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "cta cta--ghost",
    onClick: onForest
  }, /*#__PURE__*/React.createElement("span", null, "Torna nella foresta")), /*#__PURE__*/React.createElement("button", {
    className: "cta",
    onClick: onRestart
  }, /*#__PURE__*/React.createElement("span", null, "Ricomincia dalla soglia"), /*#__PURE__*/React.createElement("span", {
    className: "cta__arrow"
  }, "\u21BB"))), /*#__PURE__*/React.createElement("p", {
    className: "coro__signature"
  }, /*#__PURE__*/React.createElement("em", null, "Un progetto di Elisabetta Acquaviva"))));
}

/* ─────────────────────────────────────────────────────────────────────────
   APP — state machine + chrome
   ───────────────────────────────────────────────────────────────────────── */

function App() {
  const [scene, setScene] = useState("soglia"); // soglia | foresta | voce | coro
  const [activeVoice, setActiveVoice] = useState(null);
  const [audioOn, setAudioOn] = useState(false);

  // keyboard: Esc → back; arrows in voce → prev/next
  useEffect(() => {
    const onKey = e => {
      if (e.key === "Escape") {
        if (scene === "voce") setScene("foresta");else if (scene === "coro") setScene("foresta");
      }
      if (scene === "voce") {
        if (e.key === "ArrowRight") nextVoice();
        if (e.key === "ArrowLeft") prevVoice();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [scene, activeVoice]);
  function openVoice(id) {
    setActiveVoice(id);
    setScene("voce");
  }
  function nextVoice() {
    const ids = FORESTA_DATA.voices.map(v => v.id);
    const i = ids.indexOf(activeVoice);
    setActiveVoice(ids[(i + 1) % ids.length]);
  }
  function prevVoice() {
    const ids = FORESTA_DATA.voices.map(v => v.id);
    const i = ids.indexOf(activeVoice);
    setActiveVoice(ids[(i - 1 + ids.length) % ids.length]);
  }
  function toggleAudio() {
    if (audioOn) {
      ForestaAudio.stop();
      setAudioOn(false);
    } else {
      ForestaAudio.start();
      setAudioOn(true);
    }
  }

  // unlock audio on first user gesture (browser policy) — only if the user
  // already turned it on then refreshed: nothing to do here, it just stays off
  // until they tap the toggle.

  return /*#__PURE__*/React.createElement("div", {
    className: "app scene--" + scene
  }, /*#__PURE__*/React.createElement(GrainOverlay, null), /*#__PURE__*/React.createElement(AudioToggle, {
    on: audioOn,
    onToggle: toggleAudio
  }), /*#__PURE__*/React.createElement("header", {
    className: "app__chrome"
  }, /*#__PURE__*/React.createElement("a", {
    className: "app__mark",
    href: "#"
  }, /*#__PURE__*/React.createElement("span", {
    className: "app__mark-text"
  }, "Foresta Sospesa"), /*#__PURE__*/React.createElement("span", {
    className: "app__mark-sub"
  }, "Il Nodo di Dara \xB7 Esperienza")), /*#__PURE__*/React.createElement("nav", {
    className: "app__crumbs"
  }, /*#__PURE__*/React.createElement("button", {
    "data-active": scene === "soglia",
    onClick: () => setScene("soglia")
  }, "I \xB7 Soglia"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("button", {
    "data-active": scene === "foresta",
    onClick: () => setScene("foresta")
  }, "II \xB7 Foresta"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("button", {
    "data-active": scene === "voce",
    onClick: () => activeVoice ? setScene("voce") : null,
    disabled: !activeVoice
  }, "III \xB7 Voce"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("button", {
    "data-active": scene === "coro",
    onClick: () => setScene("coro")
  }, "IV \xB7 Coro"))), /*#__PURE__*/React.createElement("main", {
    className: "app__stage"
  }, scene === "soglia" && /*#__PURE__*/React.createElement(Soglia, {
    onEnter: () => setScene("foresta")
  }), scene === "foresta" && /*#__PURE__*/React.createElement(Foresta, {
    onOpenVoice: openVoice,
    onCoro: () => setScene("coro")
  }), scene === "voce" && /*#__PURE__*/React.createElement(Voce, {
    voiceId: activeVoice,
    onBack: () => setScene("foresta"),
    onNext: nextVoice,
    onPrev: prevVoice
  }), scene === "coro" && /*#__PURE__*/React.createElement(Coro, {
    onRestart: () => setScene("soglia"),
    onForest: () => setScene("foresta")
  })));
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "foresta-experience/app.jsx", error: String((e && e.message) || e) }); }

// foresta-experience/audio.js
try { (() => {
/* ════════════════════════════════════════════════════════════════════════
   FORESTA SOSPESA — DRONE AMBIENTALE PROCEDURALE
   Web Audio API. Nessun file audio richiesto.

   Genera un tappeto sonoro:
     · brown noise filtrato passa-basso (il "respiro" della sala)
     · sine pad lento a 110 Hz (il battito della radice)
     · una tenue armonica a 165 Hz (una quinta sopra)

   La traccia è continua e si fade-in/out morbidamente.
   I file di voce reali andranno suonati SOPRA questo drone, non al posto.
   ════════════════════════════════════════════════════════════════════════ */

window.ForestaAudio = function () {
  let ctx = null;
  let master = null;
  let started = false;
  let nodes = [];
  function ensureContext() {
    if (ctx) return ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0;
    master.connect(ctx.destination);
    return ctx;
  }
  function makeBrownNoise(durationSec) {
    const sampleRate = ctx.sampleRate;
    const buf = ctx.createBuffer(1, sampleRate * durationSec, sampleRate);
    const data = buf.getChannelData(0);
    let lastOut = 0;
    for (let i = 0; i < data.length; i++) {
      const white = Math.random() * 2 - 1;
      // simple 1-pole low-pass to brown the noise
      lastOut = (lastOut + 0.02 * white) / 1.02;
      data[i] = lastOut * 3.5;
    }
    return buf;
  }
  function start() {
    if (started) return;
    if (!ensureContext()) return;
    if (ctx.state === "suspended") ctx.resume();
    started = true;

    // ── 1. Brown-noise bed ──────────────────────────────────────────────
    const noise = ctx.createBufferSource();
    noise.buffer = makeBrownNoise(8);
    noise.loop = true;
    const noiseLP = ctx.createBiquadFilter();
    noiseLP.type = "lowpass";
    noiseLP.frequency.value = 380;
    noiseLP.Q.value = 0.6;
    const noiseGain = ctx.createGain();
    noiseGain.gain.value = 0.55;
    noise.connect(noiseLP).connect(noiseGain).connect(master);
    noise.start();
    nodes.push(noise, noiseLP, noiseGain);

    // ── 2. Slow sine pad — root ─────────────────────────────────────────
    const osc1 = ctx.createOscillator();
    osc1.type = "sine";
    osc1.frequency.value = 110;
    const osc1Gain = ctx.createGain();
    osc1Gain.gain.value = 0.07;
    osc1.connect(osc1Gain).connect(master);
    osc1.start();
    // gentle LFO on volume → the "breath"
    const lfo1 = ctx.createOscillator();
    lfo1.frequency.value = 0.08; // ~12s cycle
    const lfo1Depth = ctx.createGain();
    lfo1Depth.gain.value = 0.04;
    lfo1.connect(lfo1Depth).connect(osc1Gain.gain);
    lfo1.start();
    nodes.push(osc1, osc1Gain, lfo1, lfo1Depth);

    // ── 3. Fifth harmonic — the canopy ──────────────────────────────────
    const osc2 = ctx.createOscillator();
    osc2.type = "sine";
    osc2.frequency.value = 164.81; // ~E3
    const osc2Gain = ctx.createGain();
    osc2Gain.gain.value = 0.025;
    osc2.connect(osc2Gain).connect(master);
    osc2.start();
    const lfo2 = ctx.createOscillator();
    lfo2.frequency.value = 0.05;
    const lfo2Depth = ctx.createGain();
    lfo2Depth.gain.value = 0.018;
    lfo2.connect(lfo2Depth).connect(osc2Gain.gain);
    lfo2.start();
    nodes.push(osc2, osc2Gain, lfo2, lfo2Depth);

    // Fade in over 4 s
    const now = ctx.currentTime;
    master.gain.cancelScheduledValues(now);
    master.gain.setValueAtTime(0, now);
    master.gain.linearRampToValueAtTime(1, now + 4);
  }
  function stop() {
    if (!started || !ctx) return;
    const now = ctx.currentTime;
    master.gain.cancelScheduledValues(now);
    master.gain.linearRampToValueAtTime(0, now + 1.5);
    setTimeout(() => {
      nodes.forEach(n => {
        try {
          n.stop && n.stop();
          n.disconnect && n.disconnect();
        } catch (e) {}
      });
      nodes = [];
      started = false;
    }, 1700);
  }
  function setVolume(v) {
    if (!ctx || !master) return;
    const now = ctx.currentTime;
    master.gain.cancelScheduledValues(now);
    master.gain.linearRampToValueAtTime(Math.max(0, Math.min(1, v)), now + 0.6);
  }
  function isPlaying() {
    return started;
  }
  return {
    start,
    stop,
    setVolume,
    isPlaying
  };
}();
})(); } catch (e) { __ds_ns.__errors.push({ path: "foresta-experience/audio.js", error: String((e && e.message) || e) }); }

// foresta-experience/data.js
try { (() => {
/* ════════════════════════════════════════════════════════════════════════
   FORESTA SOSPESA — ESPERIENZA
   Frammenti di testimonianza per la traversata immersiva.

   Questi NON sono testi di repertorio. Sono frammenti illustrativi
   scritti nello stile della mostra, da sostituire con le testimonianze
   reali raccolte da Elisabetta. Strofe in stile didascalia teatrale —
   [silenzio], [un sospiro], [risata] — sono i segnali ritmici che la
   sceneggiatura usa per mostrare la voce anche in assenza dell'audio.
   ════════════════════════════════════════════════════════════════════════ */

window.FORESTA_DATA = {
  // ─── Numeri della mostra ────────────────────────────────────────────────
  // Stime per la chiusura. Sostituire con i numeri definitivi.
  stats: [{
    value: "64",
    unit: "giorni",
    caption: "7 mar — 10 mag 2026"
  }, {
    value: "100",
    unit: "ritratti",
    caption: "donne tra i 45 e i 65 anni"
  }, {
    value: "8.412",
    unit: "visite",
    caption: "ingressi registrati"
  }, {
    value: "1.300",
    unit: "voci",
    caption: "pagine sul registro"
  }],
  // ─── Voci del catalogo ──────────────────────────────────────────────────
  // Una per portrait file disponibile. Ogni voce ha:
  //   id        — chiave stabile
  //   name      — prenome (le donne sono identificate per nome di battesimo)
  //   age       — anni
  //   photo     — path relativo al file
  //   incipit   — frase di apertura, mostrata sotto la foto nella foresta
  //   stanzas   — array di blocchi; ogni blocco è { kind, text }:
  //               kind="say"  → frase pronunciata (italic serif)
  //               kind="cue"  → didascalia teatrale [silenzio] / [risata]
  //               kind="beat" → battuta breve, intensa (uppercase display)
  //   duration  — durata indicativa della traccia audio (mm:ss)
  voices: [{
    id: "eleonora",
    name: "Eleonora",
    age: 62,
    photo: "assets/imagery/locandina1.jpg",
    incipit: "All'inizio non ne ho parlato con nessuno.",
    duration: "2:14",
    stanzas: [{
      kind: "say",
      text: "All'inizio non ne ho parlato con nessuno."
    }, {
      kind: "cue",
      text: "silenzio — sei secondi"
    }, {
      kind: "say",
      text: "Mia madre non ne aveva mai parlato. Mia nonna nemmeno."
    }, {
      kind: "cue",
      text: "un respiro"
    }, {
      kind: "say",
      text: "Quando ho cominciato io, ho pensato: tocca anche a me sparire."
    }, {
      kind: "beat",
      text: "Invece sono qui."
    }]
  }, {
    id: "lorella",
    name: "Lorella",
    age: 54,
    photo: "assets/imagery/locandina4.jpg",
    incipit: "Mi svegliavo alle tre. Ogni notte.",
    duration: "1:47",
    stanzas: [{
      kind: "say",
      text: "Mi svegliavo alle tre. Ogni notte."
    }, {
      kind: "say",
      text: "Pensavo di stare impazzendo."
    }, {
      kind: "cue",
      text: "risata breve"
    }, {
      kind: "say",
      text: "Poi ho scoperto che eravamo in milioni, alle tre di notte, sveglie."
    }, {
      kind: "beat",
      text: "Una specie di coro silenzioso. Mi è piaciuto."
    }]
  }, {
    id: "chiara",
    name: "Chiara",
    age: 49,
    photo: "assets/imagery/locandina6.jpg",
    incipit: "Il corpo cambia prima della testa.",
    duration: "1:12",
    stanzas: [{
      kind: "say",
      text: "Il corpo cambia prima della testa."
    }, {
      kind: "say",
      text: "La testa si arrabbia."
    }, {
      kind: "cue",
      text: "pausa"
    }, {
      kind: "say",
      text: "Poi capisce."
    }, {
      kind: "beat",
      text: "Poi ringrazia, qualche volta."
    }]
  }, {
    id: "lucia",
    name: "Lucia",
    age: 58,
    photo: "assets/imagery/locandina10.jpg",
    incipit: "Mio marito mi ha detto: «Sei diversa.»",
    duration: "1:38",
    stanzas: [{
      kind: "say",
      text: "Mio marito mi ha detto: «Sei diversa.»"
    }, {
      kind: "say",
      text: "Gli ho risposto: «Lo so.»"
    }, {
      kind: "cue",
      text: "silenzio"
    }, {
      kind: "say",
      text: "Non era una domanda."
    }, {
      kind: "say",
      text: "Non era una scusa."
    }, {
      kind: "beat",
      text: "Era una soglia."
    }]
  }, {
    id: "monica",
    name: "Monica",
    age: 51,
    photo: "assets/imagery/locandina12.jpg",
    incipit: "Pensavo che sarebbe stata la fine di qualcosa.",
    duration: "1:55",
    stanzas: [{
      kind: "say",
      text: "Pensavo che sarebbe stata la fine di qualcosa."
    }, {
      kind: "cue",
      text: "un sospiro lungo"
    }, {
      kind: "say",
      text: "Era l'inizio."
    }, {
      kind: "beat",
      text: "Solo che nessuno me l'aveva detto."
    }]
  }, {
    id: "eugenia",
    name: "Eugenia",
    age: 65,
    photo: "assets/imagery/locandina15.jpg",
    incipit: "Adesso dormo poco e leggo tanto.",
    duration: "1:09",
    stanzas: [{
      kind: "say",
      text: "Adesso dormo poco e leggo tanto."
    }, {
      kind: "cue",
      text: "risata"
    }, {
      kind: "say",
      text: "Mi sembra un buon affare."
    }, {
      kind: "cue",
      text: "un silenzio caldo"
    }, {
      kind: "beat",
      text: "Non tornerei indietro."
    }]
  }],
  // ─── Frammenti del coro finale ──────────────────────────────────────────
  // Sussurri che salgono dalle tende nell'Atto IV. Da sostituire con le
  // frasi reali del muro delle dediche / del registro dei visitatori.
  chorus: ["non ero sola", "ho smesso di vergognarmi", "mia madre non me l'aveva detto", "ho cominciato a dormire di giorno", "ho riconosciuto mia nonna nello specchio", "ho capito che era un inizio", "ho pianto, ma di sollievo", "ho riso, finalmente", "non è una fine", "è una radice"],
  // ─── Posizionamento 3D nella foresta ────────────────────────────────────
  // x in vw da -45 a +45, y in vh da -10 a +10 (alto/basso), z in px
  // (negativo = più lontano dalla camera). Sway: durata, ritardo, ampiezza.
  // Le 6 voci sono disposte in due "file" di profondità per dare l'idea
  // di attraversare una foresta, non guardarla da fuori.
  layout: [{
    id: "eleonora",
    x: -28,
    y: -4,
    z: -200,
    w: 320,
    sway: {
      d: 6.4,
      lag: 0.0,
      amp: 0.9
    }
  }, {
    id: "lorella",
    x: 18,
    y: 2,
    z: -120,
    w: 360,
    sway: {
      d: 7.1,
      lag: 1.2,
      amp: 1.1
    }
  }, {
    id: "chiara",
    x: -10,
    y: -6,
    z: -480,
    w: 240,
    sway: {
      d: 5.8,
      lag: 0.6,
      amp: 0.7
    }
  }, {
    id: "lucia",
    x: 34,
    y: -2,
    z: -360,
    w: 280,
    sway: {
      d: 6.7,
      lag: 2.0,
      amp: 1.0
    }
  }, {
    id: "monica",
    x: -34,
    y: 3,
    z: -640,
    w: 220,
    sway: {
      d: 7.5,
      lag: 0.3,
      amp: 0.6
    }
  }, {
    id: "eugenia",
    x: 6,
    y: -3,
    z: -780,
    w: 200,
    sway: {
      d: 5.5,
      lag: 1.7,
      amp: 0.5
    }
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "foresta-experience/data.js", error: String((e && e.message) || e) }); }

})();
